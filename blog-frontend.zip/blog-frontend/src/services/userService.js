// import { axiosInstance } from './axiosInstance'

// export const getMe = async () => {
//   const { data } = await axiosInstance.get('/user/me')
//   return data?.user
// }

// export const getMyPosts = async () => {
//   const { data } = await axiosInstance.get('/user/posts')
//   return data?.posts || []
// }

// export const updateOwnPost = async (postId, payload) => {
//   const { data } = await axiosInstance.patch(`/user/${postId}`, payload)
//   return data?.post
// }

