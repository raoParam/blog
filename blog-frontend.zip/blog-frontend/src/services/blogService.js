import axiosInstance from "./axiosInstance";

export const getPublicPosts = async () => {
  const response = await axiosInstance.get("/public/posts");
  return response.data.blogs;
};

































// import { axiosInstance } from './axiosInstance'

// export const createBlog = async (payload) => {
//   const { data } = await axiosInstance.post('/posts/', payload)
//   return data?.blog
// }

// export const getBlogs = async () => {
//   const { data } = await axiosInstance.get('/posts/posts')
//   return data?.blogs || []
// }

// export const getBlog = async (postId) => {
//   const { data } = await axiosInstance.get(`/posts/${postId}`)
//   return data?.blog
// }

// export const updateBlog = async (postId, payload) => {
//   const { data } = await axiosInstance.put(`/posts/${postId}`, payload)
//   return data?.blog
// }

// export const deleteBlog = async (postId) => {
//   const { data } = await axiosInstance.delete(`/posts/${postId}`)
//   return data
// }

// export const likeBlog = async (postId) => {
//   const { data } = await axiosInstance.post(`/posts/${postId}/like`)
//   return data
// }

// export const getPublicPosts = async () => {
//   const { data } = await axiosInstance.get('/public/posts')
//   console.log(data)
//   return data?.blogs || []
// }

// export const getPublicPost = async (postId) => {
//   const { data } = await axiosInstance.get(`/public/posts/${postId}`)
//   return data?.blog
// }

