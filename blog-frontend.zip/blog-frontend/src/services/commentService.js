// // Comment APIs are not defined in the backend contract.
// // This file exists to keep the frontend structure consistent.
// // You can later wire these functions to real endpoints.

// export const getCommentsForPost = async () => {
//   return []
// }

// export const addCommentToPost = async () => {
//   return null
// }

