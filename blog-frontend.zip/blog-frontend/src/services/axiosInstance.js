import axios from "axios";

const axiosInstance = axios.create({
  baseURL: "http://localhost:3000/api",
  headers: {
    "Content-Type": "application/json",
  },
});



axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('blog_jwt')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => Promise.reject(error),
)

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) {
      localStorage.removeItem('blog_jwt')
      localStorage.removeItem('blog_user')
      window.dispatchEvent(new Event('auth:logout'))
    }
    return Promise.reject(error)
  },
)

export const setAuthToken = (token) => {
  if (token) {
    localStorage.setItem('blog_jwt', token)
  } else {
    localStorage.removeItem('blog_jwt')
  }
}
export default axiosInstance
