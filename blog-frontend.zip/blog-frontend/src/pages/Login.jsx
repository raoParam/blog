// import React,{ useState } from 'react'
// import { useLocation } from 'react-router-dom'
// import { Input } from '../components/common/Input'
// import { Button } from '../components/common/Button'
// import { useAuth } from '../hooks/useAuth'

// export const Login = () => {
//   const { login, authError } = useAuth()
//   const location = useLocation()
//   const [form, setForm] = useState({ emailId: '', password: '' })
//   const [fieldErrors, setFieldErrors] = useState({})
//   const [submitting, setSubmitting] = useState(false)

//   const handleChange = (e) => {
//     setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
//   }

//   const handleSubmit = async (e) => {
//     e.preventDefault()
//     if (submitting) return

//     const emailId = form.emailId.trim()
//     const password = form.password.trim()
//     const errors = {}
//     if (!emailId) errors.emailId = 'Email is required.'
//     if (!password) errors.password = 'Password is required.'
//     setFieldErrors(errors)
//     if (Object.keys(errors).length > 0) return

//     setSubmitting(true)
//     const result = await login({ emailId, password })
//     setSubmitting(false)

//     if (!result.success) return
//     const from = location.state?.from?.pathname
//     if (from) {
//       window.location.replace(from)
//     }
//   }

//   return (
//     <div className="mx-auto w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
//       <h1 className="text-lg font-semibold text-slate-900">Welcome back</h1>
//       <p className="mt-1 text-xs text-slate-500">
//         Sign in to access your personalized feed.
//       </p>

//       <form onSubmit={handleSubmit} className="mt-4 space-y-3">
//         <Input
//           label="Email"
//           name="emailId"
//           type="email"
//           value={form.emailId}
//           onChange={handleChange}
//           placeholder="you@example.com"
//           required
//           error={fieldErrors.emailId}
//         />
//         <Input
//           label="Password"
//           name="password"
//           type="password"
//           value={form.password}
//           onChange={handleChange}
//           placeholder="••••••••"
//           required
//           error={fieldErrors.password}
//         />

//         {authError && (
//           <p className="text-xs text-red-600" role="alert">
//             {authError}
//           </p>
//         )}

//         <Button type="submit" className="w-full" disabled={submitting}>
//           {submitting ? 'Logging in...' : 'Login'}
//         </Button>
//       </form>
//     </div>
//   )
// }

