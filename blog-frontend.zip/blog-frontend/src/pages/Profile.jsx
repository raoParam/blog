// import React from 'react'
// import { useFetch } from '../hooks/useFetch'
// import { getMe, getMyPosts } from '../services/userService'
// import { Loader } from '../components/common/Loader'
// import { ErrorState } from '../components/common/ErrorState'
// import { ProfileHeader } from '../components/user/ProfileHeader'
// import { ProfileTabs } from '../components/user/ProfileTabs'
// import { UserPostList } from '../components/user/UserPostList'

// export const Profile = () => {
//   const { data: user, loading: userLoading, error: userError } = useFetch(
//     getMe,
//     [],
//   )
//   const {
//     data: posts,
//     loading: postsLoading,
//     error: postsError,
//   } = useFetch(getMyPosts, [])

//   if (userLoading || postsLoading) return <Loader />
//   if (userError) return <ErrorState message={userError} />
//   if (postsError) return <ErrorState message={postsError} />

//   return (
//     <div>
//       <ProfileHeader user={user} />
//       <ProfileTabs />
//       <UserPostList posts={posts} />
//     </div>
//   )
// }

