// import React, { useState } from 'react'
// import { useNavigate } from 'react-router-dom'
// import { CreateBlogForm } from '../components/blog/CreateBlogForm'
// import { createBlog } from '../services/blogService'

// export const CreateBlog = () => {
//   const navigate = useNavigate()
//   const [saving, setSaving] = useState(false)

//   const handleSubmit = async (payload) => {
//     if (saving) return
//     setSaving(true)
//     try {
//       const blog = await createBlog(payload)
//       if (blog?._id) {
//         navigate(`/blogs/${blog._id}`)
//       } else {
//         navigate('/home')
//       }
//     } catch {
//       // error toast could go here
//     } finally {
//       setSaving(false)
//     }
//   }

//   return (
//     <div>
//       <h1 className="mb-4 text-lg font-semibold text-slate-900">
//         Create a new blog
//       </h1>
//       <CreateBlogForm onSubmit={handleSubmit} loading={saving} />
//     </div>
//   )
// }

