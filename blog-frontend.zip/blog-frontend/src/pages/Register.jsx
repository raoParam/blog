// import React, { useState } from 'react'
// import { Input } from '../components/common/Input'
// import { Button } from '../components/common/Button'
// import { useAuth } from '../hooks/useAuth'

// export const Register = () => {
//   const { register, authError } = useAuth()
//   const [form, setForm] = useState({ username: '', email: '', password: '' })
//   const [fieldErrors, setFieldErrors] = useState({})
//   const [submitting, setSubmitting] = useState(false)

//   const handleChange = (e) => {
//     setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
//   }

//   const handleSubmit = async (e) => {
//     e.preventDefault()
//     if (submitting) return

//     const username = form.username.trim()
//     const email = form.email.trim()
//     const password = form.password.trim()
//     const errors = {}
//     if (!username) errors.username = 'Username is required.'
//     if (!email) errors.email = 'Email is required.'
//     if (!password) errors.password = 'Password is required.'
//     if (password && password.length < 6) {
//       errors.password = 'Password must be at least 6 characters.'
//     }
//     setFieldErrors(errors)
//     if (Object.keys(errors).length > 0) return

//     setSubmitting(true)
//     await register({ username, email, password })
//     setSubmitting(false)
//   }

//   return (
//     <div className="mx-auto w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
//       <h1 className="text-lg font-semibold text-slate-900">Create account</h1>
//       <p className="mt-1 text-xs text-slate-500">
//         Join the community and start writing.
//       </p>

//       <form onSubmit={handleSubmit} className="mt-4 space-y-3">
//         <Input
//           label="Username"
//           name="username"
//           value={form.username}
//           onChange={handleChange}
//           placeholder="yourname"
//           required
//           error={fieldErrors.username}
//         />
//         <Input
//           label="Email"
//           name="email"
//           type="email"
//           value={form.email}
//           onChange={handleChange}
//           placeholder="you@example.com"
//           required
//           error={fieldErrors.email}
//         />
//         <Input
//           label="Password"
//           name="password"
//           type="password"
//           value={form.password}
//           onChange={handleChange}
//           placeholder="••••••••"
//           required
//           error={fieldErrors.password}
//         />

//         {authError && (
//           <p className="text-xs text-red-600" role="alert">
//             {authError}
//           </p>
//         )}

//         <Button type="submit" className="w-full" disabled={submitting}>
//           {submitting ? 'Creating account...' : 'Sign up'}
//         </Button>
//       </form>
//     </div>
//   )
// }

