// import React from 'react'
// import { useNavigate, useParams } from 'react-router-dom'
// import { useFetch } from '../hooks/useFetch'
// import { getBlog } from '../services/blogService'
// import { Loader } from '../components/common/Loader'
// import { ErrorState } from '../components/common/ErrorState'
// import { BlogContent } from '../components/blog/BlogContent'
// import { BlogActions } from '../components/blog/BlogActions'
// import { formatDate } from '../utils/formatDate'
// import { CommentList } from '../components/comment/CommentList'
// import { CommentForm } from '../components/comment/CommentForm'

// export const SingleBlog = () => {
//   const { postId } = useParams()
//   const navigate = useNavigate()
//   const { data: blog, loading, error } = useFetch(
//     () => getBlog(postId),
//     [postId],
//   )

//   if (loading) return <Loader />
//   if (error) return <ErrorState message={error} />
//   if (!blog) return <ErrorState message="Blog not found." />

//   const authorLabel = blog.isAnonymous
//     ? 'Anonymous'
//     : blog.author?.username || 'Unknown'

//   return (
//     <div className="space-y-4">
//       <button
//         type="button"
//         className="text-xs text-blue-600 hover:underline"
//         onClick={() => navigate(-1)}
//       >
//         ← Back
//       </button>

//       <article className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm">
//         <header className="mb-4">
//           <h1 className="text-xl font-semibold text-slate-900">
//             {blog.title}
//           </h1>
//           <p className="mt-1 text-xs text-slate-500">
//             {authorLabel} • {formatDate(blog.createdAt)}
//           </p>
//         </header>
//         <BlogContent content={blog.content} />
//         <div className="mt-4">
//           <BlogActions blog={blog} />
//         </div>
//       </article>

//       <section className="space-y-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
//         <h2 className="text-sm font-semibold text-slate-900">Comments</h2>
//         <CommentForm />
//         <CommentList comments={[]} />
//       </section>
//     </div>
//   )
// }

