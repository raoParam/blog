
import React from 'react'
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import MainLayout from "../components/layout/MainLayout";
import BlogCard from "../components/blog/BlogCard";
import {Loader} from "../components/common/Loader";
import {EmptyState} from "../components/common/EmptyState";
import { getPublicPosts } from "../services/blogService";
import { useNavigate } from "react-router-dom";
import Button from '../components/common/Button'

const Landing = () => {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const data = await getPublicPosts();
        setPosts(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchPosts();
  }, []);

  return (
    <MainLayout>
      {/* HERO */}
      <section className="relative max-w-6xl mx-auto text-center py-36 px-6">

  <motion.div
    initial="hidden"
    animate="visible"
    variants={{
      hidden: {},
      visible: {
        transition: {
          staggerChildren: 0.2
        }
      }
    }}
  >
    <motion.h1
      variants={{
        hidden: { opacity: 0, y: 30 },
        visible: { opacity: 1, y: 0 }
      }}
      transition={{ duration: 0.8 }}
      className="text-6xl md:text-7xl font-bold leading-tight mb-8"
    >
      <span className="bg-gradient-to-r from-white to-neutral-400 bg-clip-text text-transparent">
        Write without noise.
      </span>
    </motion.h1>

    <motion.p
      variants={{
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 }
      }}
      transition={{ duration: 0.8 }}
      className="text-neutral-400 text-xl max-w-3xl mx-auto mb-12"
    >
      A calm space for serious writing. Stay anonymous or build your identity.
      Publish ideas that matter.
    </motion.p>

    <motion.div
      variants={{
        hidden: { opacity: 0 },
        visible: { opacity: 1 }
      }}
      className="flex justify-center gap-6"
    >
      <Button
        variant="primary"
        onClick={() => navigate("/register")}
      >
        Start Writing
      </Button>

      <Button
        variant="outline"
        onClick={() => navigate("/login")}
      >
        Explore
      </Button>
    </motion.div>
  </motion.div>

  {/* Decorative Line */}
  <div className="mt-24 h-[1px] bg-gradient-to-r from-transparent via-neutral-700 to-transparent"></div>
</section>


      {/* FEATURED POSTS */}
      <section className="max-w-6xl mx-auto px-6 pb-28">

  <motion.h2
    initial={{ opacity: 0, y: 30 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.6 }}
    className="text-4xl font-semibold mb-16 text-center"
  >
    Featured Writing
  </motion.h2>

  {loading ? (
    <Loader />
  ) : posts.length === 0 ? (
    <EmptyState message="No public posts yet." />
  ) : (
    <motion.div
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={{
        hidden: {},
        visible: {
          transition: {
            staggerChildren: 0.15
          }
        }
      }}
      className="grid md:grid-cols-2 gap-12"
    >
      {posts.slice(0, 4).map((blog) => (
        <motion.div
          key={blog._id}
          variants={{
            hidden: { opacity: 0, y: 40 },
            visible: { opacity: 1, y: 0 }
          }}
        >
          <BlogCard blog={blog} />
        </motion.div>
      ))}
    </motion.div>
  )}
</section>

    </MainLayout>
  );
};

export default Landing;




























// import { useNavigate } from 'react-router-dom'
// import { BlogList } from '../components/blog/BlogList'
// import { Loader } from '../components/common/Loader'
// import { ErrorState } from '../components/common/ErrorState'
// import { Button } from '../components/common/Button'
// import { useFetch } from '../hooks/useFetch'
// import { getPublicPosts } from '../services/blogService'
// import React from 'react'

// export const Landing = () => {
//   const navigate = useNavigate()
//   const { data: posts, loading, error } = useFetch(getPublicPosts, [])

//   return (
//     <div className="space-y-6">
//       <section className="rounded-xl border border-slate-200 bg-gradient-to-r from-blue-50 to-indigo-50 p-6 shadow-sm">
//         <h1 className="text-xl font-semibold text-slate-900">
//           Discover stories from the community
//         </h1>
//         <p className="mt-2 max-w-xl text-sm text-slate-600">
//           Read public posts from writers across the platform. Sign in to like,
//           create, and manage your own blogs.
//         </p>
//         <div className="mt-4 flex flex-wrap gap-2">
//           <Button onClick={() => navigate('/login')}>Login</Button>
//           <Button variant="outline" onClick={() => navigate('/register')}>
//             Create an account
//           </Button>
//         </div>
//       </section>

//       <section className="space-y-3">
//         <h2 className="text-sm font-semibold text-slate-900">
//           Latest public posts
//         </h2>
//         {loading && <Loader />}
//         {!loading && error && <ErrorState message={error} />}
//         {!loading && !error && <BlogList blogs={posts} pageSize={10} />}
//       </section>
//     </div>
//   )
// }

