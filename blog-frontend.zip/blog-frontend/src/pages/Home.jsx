// import React, { useState } from 'react'
// import { BlogList } from '../components/blog/BlogList'
// import { Loader } from '../components/common/Loader'
// import { ErrorState } from '../components/common/ErrorState'
// import { useFetch } from '../hooks/useFetch'
// import { getBlogs } from '../services/blogService'

// export const Home = () => {
//   const { data: blogs, loading, error, setData } = useFetch(getBlogs, [])
//   const [pageSize] = useState(10)

//   const handleLikeOptimistic = (id) => {
//     setData((prev) => {
//       if (!prev) return prev
//       return prev.map((blog) =>
//         blog._id === id
//           ? { ...blog, likes: [...(blog.likes || []), 'me-temp'] }
//           : blog,
//       )
//     })
//   }

//   return (
//     <div className="space-y-4">
//       <header className="flex items-center justify-between">
//         <h1 className="text-lg font-semibold text-slate-900">Your feed</h1>
//       </header>
//       {loading && <Loader />}
//       {!loading && error && <ErrorState message={error} />}
//       {!loading && !error && (
//         <BlogList
//           blogs={blogs}
//           pageSize={pageSize}
//           onLikeOptimistic={handleLikeOptimistic}
//         />
//       )}
//     </div>
//   )
// }

