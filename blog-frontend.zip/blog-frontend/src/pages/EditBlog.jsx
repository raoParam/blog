// import React, { useState } from 'react'
// import { useNavigate, useParams } from 'react-router-dom'
// import { useFetch } from '../hooks/useFetch'
// import { getBlog, updateBlog } from '../services/blogService'
// import { Loader } from '../components/common/Loader'
// import { ErrorState } from '../components/common/ErrorState'
// import { EditBlogForm } from '../components/blog/EditBlogForm'
// import { useAuth } from '../hooks/useAuth'

// export const EditBlog = () => {
//   const { postId } = useParams()
//   const navigate = useNavigate()
//   const { user } = useAuth()
//   const { data: blog, loading, error } = useFetch(
//     () => getBlog(postId),
//     [postId],
//   )
//   const [saving, setSaving] = useState(false)

//   if (loading) return <Loader />
//   if (error) return <ErrorState message={error} />
//   if (!blog) return <ErrorState message="Blog not found." />

//   if (user && blog.author?._id !== user._id) {
//     return <ErrorState message="You are not allowed to edit this blog." />
//   }

//   const handleSubmit = async (payload) => {
//     if (saving) return
//     setSaving(true)
//     try {
//       const updated = await updateBlog(postId, payload)
//       if (updated?._id) {
//         navigate(`/blogs/${updated._id}`)
//       } else {
//         navigate('/home')
//       }
//     } catch {
//       // error toast could go here
//     } finally {
//       setSaving(false)
//     }
//   }

//   return (
//     <div>
//       <h1 className="mb-4 text-lg font-semibold text-slate-900">
//         Edit blog post
//       </h1>
//       <EditBlogForm
//         initialValues={{
//           title: blog.title,
//           content: blog.content,
//           isAnonymous: blog.isAnonymous,
//         }}
//         onSubmit={handleSubmit}
//         loading={saving}
//       />
//     </div>
//   )
// }

