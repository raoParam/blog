// import React from 'react'
// import { Link } from 'react-router-dom'

// export const NotFound = () => {
//   return (
//     <div className="flex min-h-[60vh] flex-col items-center justify-center text-center">
//       <p className="text-4xl font-bold text-slate-200">404</p>
//       <h1 className="mt-2 text-lg font-semibold text-slate-900">
//         Page not found
//       </h1>
//       <p className="mt-1 max-w-sm text-xs text-slate-500">
//         The page you are looking for might have been removed or is temporarily
//         unavailable.
//       </p>
//       <Link
//         to="/"
//         className="mt-4 rounded-md bg-blue-600 px-4 py-2 text-xs font-medium text-white shadow-sm hover:bg-blue-700"
//       >
//         Go back home
//       </Link>
//     </div>
//   )
// }

