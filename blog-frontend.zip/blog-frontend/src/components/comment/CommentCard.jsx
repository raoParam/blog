// import React from 'react'

// export const CommentCard = ({ comment }) => {
//   return (
//     <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs">
//       <p className="text-slate-800">{comment.content}</p>
//       <p className="mt-1 text-[11px] text-slate-500">
//         {comment.author || 'Anonymous'}
//       </p>
//     </div>
//   )
// }

