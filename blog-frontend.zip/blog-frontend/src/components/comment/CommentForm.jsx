// import React, { useState } from 'react'
// import { Button } from '../common/Button'

// export const CommentForm = () => {
//   const [value, setValue] = useState('')
//   const [submitting, setSubmitting] = useState(false)

//   const handleSubmit = (e) => {
//     e.preventDefault()
//     if (submitting) return
//     const trimmed = value.trim()
//     if (!trimmed) return
//     setSubmitting(true)
//     // Comments are not persisted because no API is defined.
//     // This is a UI-only component for now.
//     setTimeout(() => {
//       setSubmitting(false)
//       setValue('')
//     }, 500)
//   }

//   return (
//     <form onSubmit={handleSubmit} className="space-y-2">
//       <textarea
//         rows={3}
//         className="w-full rounded-md border border-slate-300 px-3 py-2 text-xs shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
//         placeholder="Add a comment..."
//         value={value}
//         onChange={(e) => setValue(e.target.value)}
//       />
//       <div className="flex justify-end">
//         <Button type="submit" size="sm" disabled={submitting}>
//           {submitting ? 'Posting...' : 'Post comment'}
//         </Button>
//       </div>
//     </form>
//   )
// }

