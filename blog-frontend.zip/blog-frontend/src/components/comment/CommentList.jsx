// import React from 'react'
// import { CommentCard } from './CommentCard'
// import { EmptyState } from '../common/EmptyState'

// export const CommentList = ({ comments }) => {
//   if (!comments || comments.length === 0) {
//     return (
//       <EmptyState
//         title="No comments yet"
//         message="Be the first to start a conversation."
//       />
//     )
//   }

//   return (
//     <div className="space-y-3">
//       {comments.map((comment) => (
//         <CommentCard key={comment._id} comment={comment} />
//       ))}
//     </div>
//   )
// }

