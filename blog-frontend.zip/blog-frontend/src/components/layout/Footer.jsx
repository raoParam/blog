import React from 'react'
const Footer = () => {
  return (
    <footer className="text-center py-6 border-t border-[#2a2a2a] bg-[#111111] text-gray-500 text-sm">
      © {new Date().getFullYear()} BlogSpace. All rights reserved.
    </footer>
  );
};

export default Footer;
























// import React from 'react'
// export const Footer = () => {
//   return (
//     <footer className="border-t border-slate-200 bg-white/80">
//       <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 text-xs text-slate-500">
//         <p>&copy; {new Date().getFullYear()} Blog App. All rights reserved.</p>
//         <p className="hidden md:block">Built with React &amp; Tailwind CSS.</p>
//       </div>
//     </footer>
//   )
// }

