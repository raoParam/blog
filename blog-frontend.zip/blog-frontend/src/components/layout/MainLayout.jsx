import React from 'react'
import Navbar from "./Navbar";
import Footer from "./Footer";

const MainLayout = ({ children }) => {
  return (
    <div className="relative min-h-screen bg-[#0b0b0c] text-white overflow-hidden">
      
      {/* Background Glow Effects */}
      <div className="absolute top-[-200px] left-[-200px] w-[500px] h-[500px] bg-[#c2410c]/20 blur-[140px] rounded-full"></div>
      <div className="absolute bottom-[-200px] right-[-200px] w-[500px] h-[500px] bg-[#ea580c]/10 blur-[160px] rounded-full"></div>

      <Navbar />
      <main className="relative z-10">{children}</main>
      <Footer />
    </div>
  );
};

export default MainLayout;

















// import { Outlet } from 'react-router-dom'
// import { Navbar } from './Navbar'
// import { Footer } from './Footer'
// import { Sidebar } from './Sidebar'
// import React from 'react'

// export const MainLayout = () => {
//   return (
//     <div className="flex min-h-screen flex-col bg-slate-50">
//       <Navbar />
//       <main className="mx-auto flex w-full max-w-6xl flex-1 gap-6 px-4 py-6">
//         <Sidebar />
//         <section className="flex-1">
//           <Outlet />
//         </section>
//       </main>
//       <Footer />
//     </div>
//   )
// }

