// import { NavLink } from 'react-router-dom'
// import { useAuth } from '../../hooks/useAuth'
// import React from 'react'

// export const Sidebar = () => {
//   const { isAuthenticated } = useAuth()

//   if (!isAuthenticated) {
//     return null
//   }

//   return (
//     <aside className="sticky top-20 hidden h-[calc(100vh-5rem)] w-56 flex-shrink-0 border-r border-slate-200 bg-white/80 px-4 py-4 md:block">
//       <nav className="space-y-1 text-sm font-medium text-slate-600">
//         <NavLink
//           to="/home"
//           className={({ isActive }) =>
//             `flex items-center justify-between rounded-md px-3 py-2 ${
//               isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100'
//             }`
//           }
//         >
//           <span>Feed</span>
//         </NavLink>
//         <NavLink
//           to="/blogs/create"
//           className={({ isActive }) =>
//             `flex items-center justify-between rounded-md px-3 py-2 ${
//               isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100'
//             }`
//           }
//         >
//           <span>Create post</span>
//         </NavLink>
//         <NavLink
//           to="/profile"
//           className={({ isActive }) =>
//             `flex items-center justify-between rounded-md px-3 py-2 ${
//               isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100'
//             }`
//           }
//         >
//           <span>My profile</span>
//         </NavLink>
//       </nav>
//     </aside>
//   )
// }

