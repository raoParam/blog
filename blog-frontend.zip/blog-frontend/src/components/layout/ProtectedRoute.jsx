// import { Navigate, useLocation } from 'react-router-dom'
// import { useAuth } from '../../hooks/useAuth'
// import React from 'react'

// export const ProtectedRoute = ({ children }) => {
//   const { isAuthenticated, loading } = useAuth()
//   const location = useLocation()

//   if (loading) {
//     return (
//       <div className="flex min-h-[60vh] items-center justify-center">
//         <div className="h-10 w-10 animate-spin rounded-full border-4 border-slate-300 border-t-blue-600" />
//       </div>
//     )
//   }

//   if (!isAuthenticated) {
//     return <Navigate to="/login" replace state={{ from: location }} />
//   }

//   return children
// }

