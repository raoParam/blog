import { Link } from "react-router-dom";
import React from 'react'
import { motion } from "framer-motion";
import Button from '../common/Button'

const Navbar = () => {
  return (
    <motion.nav
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="flex justify-between items-center px-12 py-6 bg-[#0f0f0f] border-b border-neutral-800"
    >
      <Link to="/" className="text-2xl font-semibold tracking-tight text-white">
        BlogSpace
      </Link>

      <div className="space-x-6">
        <Link to="/login" className="text-neutral-300 hover:text-white transition">
          Login
        </Link>
        <Button to="/register" className="btn btn-sm bg-[#c2410c] hover:bg-[#ea580c] border-none text-white">
          Get Started
        </Button>
      </div>
    </motion.nav>
  );
};

export default Navbar;








// import { Link, NavLink, useNavigate } from 'react-router-dom'
// import { useAuth } from '../../hooks/useAuth'
// import { Button } from '../common/Button'
// import React from 'react'

// export const Navbar = () => {
//   const { isAuthenticated, user, logout } = useAuth()
//   const navigate = useNavigate()

//   const handleLogoutClick = () => {
//     logout()
//   }

//   return (
//     <header className="border-b border-slate-200 bg-white/80 backdrop-blur">
//       <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
//         <Link to="/" className="flex items-center gap-2">
//           <span className="rounded bg-blue-600 px-2 py-1 text-sm font-semibold text-white">
//             Blog
//           </span>
//           <span className="text-lg font-semibold text-slate-900">App</span>
//         </Link>

//         <nav className="flex items-center gap-4 text-sm font-medium text-slate-600">
//           {isAuthenticated && (
//             <>
//               <NavLink
//                 to="/home"
//                 className={({ isActive }) =>
//                   `hidden rounded-md px-3 py-1.5 md:inline-block ${
//                     isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100'
//                   }`
//                 }
//               >
//                 Home
//               </NavLink>
//               <NavLink
//                 to="/blogs/create"
//                 className={({ isActive }) =>
//                   `hidden rounded-md px-3 py-1.5 md:inline-block ${
//                     isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100'
//                   }`
//                 }
//               >
//                 Create
//               </NavLink>
//               <NavLink
//                 to="/profile"
//                 className={({ isActive }) =>
//                   `hidden rounded-md px-3 py-1.5 md:inline-block ${
//                     isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100'
//                   }`
//                 }
//               >
//                 Profile
//               </NavLink>
//             </>
//           )}

//           {!isAuthenticated ? (
//             <div className="flex items-center gap-2">
//               <Button
//                 variant="ghost"
//                 size="sm"
//                 onClick={() => navigate('/login')}
//               >
//                 Login
//               </Button>
//               <Button size="sm" onClick={() => navigate('/register')}>
//                 Sign up
//               </Button>
//             </div>
//           ) : (
//             <div className="flex items-center gap-3">
//               <span className="hidden text-sm text-slate-700 md:inline">
//                 {user?.username}
//               </span>
//               <Button size="sm" variant="ghost" onClick={handleLogoutClick}>
//                 Logout
//               </Button>
//             </div>
//           )}
//         </nav>
//       </div>
//     </header>
//   )
// }

