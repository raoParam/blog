// import React from 'react'
// export const ErrorState = ({ message, onRetry }) => {
//   return (
//     <div className="flex min-h-[40vh] flex-col items-center justify-center text-center">
//       <div className="mb-3 h-10 w-10 rounded-full bg-red-50" />
//       <h2 className="text-sm font-semibold text-red-600">Something went wrong</h2>
//       {message && (
//         <p className="mt-1 max-w-sm text-xs text-slate-600">{message}</p>
//       )}
//       {onRetry && (
//         <button
//           type="button"
//           onClick={onRetry}
//           className="mt-3 inline-flex items-center rounded-md bg-red-600 px-3 py-1.5 text-xs font-medium text-white shadow-sm hover:bg-red-700"
//         >
//           Try again
//         </button>
//       )}
//     </div>
//   )
// }

