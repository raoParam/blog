// import React from 'react'

// export const Input = ({
//   label,
//   type = 'text',
//   name,
//   value,
//   onChange,
//   placeholder,
//   error,
//   required,
//   ...rest
// }) => {
//   return (
//     <div className="space-y-1">
//       {label && (
//         <label
//           htmlFor={name}
//           className="block text-sm font-medium text-slate-700"
//         >
//           {label}
//           {required && <span className="text-red-500"> *</span>}
//         </label>
//       )}
//       <input
//         id={name}
//         name={name}
//         type={type}
//         value={value ?? ''}
//         onChange={onChange}
//         placeholder={placeholder}
//         className={`w-full rounded-md border px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 ${
//           error ? 'border-red-500' : 'border-slate-300'
//         }`}
//         {...rest}
//       />
//       {error && <p className="text-xs text-red-500">{error}</p>}
//     </div>
//   )
// }

