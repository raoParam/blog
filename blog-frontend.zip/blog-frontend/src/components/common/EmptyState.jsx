import React from 'react'

export const EmptyState = ({ title = 'Nothing here yet', message }) => {
  return (
    <div className="flex min-h-[40vh] flex-col items-center justify-center text-center">
      <div className="mb-3 h-10 w-10 rounded-full bg-slate-100" />
      <h2 className="text-sm font-semibold text-slate-800">{title}</h2>
      {message && (
        <p className="mt-1 max-w-sm text-xs text-slate-500">{message}</p>
      )}
    </div>
  )
}


// const EmptyState = ({ message }) => {
//   return (
//     <div className="text-center py-10 text-gray-500">
//       {message}
//     </div>
//   );
// };

// export default EmptyState;

