import React from 'react'
export const Loader = () => {
  return (
    <div className="flex min-h-[40vh] items-center justify-center">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-slate-300 border-t-blue-600" />
    </div>
  )
}

// const Loader = () => {
//   return (
//     <div className="text-center py-10 text-gray-400">
//       Loading...
//     </div>
//   );
// };

// export default Loader;


