import React from 'react'
import { motion } from "framer-motion";

const Button = ({
  children,
  onClick,
  variant = "primary",
  className = "",
  type = "button",
}) => {
  const baseStyles =
    "px-8 py-3 rounded-lg font-medium text-sm tracking-wide transition-all duration-300 focus:outline-none";

  const variants = {
    primary:
      "bg-[#c2410c] text-white shadow-[0_0_0_1px_rgba(0,0,0,0.3)] hover:bg-[#ea580c] hover:shadow-[0_0_20px_rgba(194,65,12,0.25)]",
    outline:
      "border border-neutral-700 text-neutral-300 hover:text-white hover:border-neutral-500 bg-transparent",
  };

  return (
    <motion.button
      whileTap={{ scale: 0.97 }}
      whileHover={{ y: -2 }}
      transition={{ type: "spring", stiffness: 250 }}
      type={type}
      onClick={onClick}
      className={`${baseStyles} ${variants[variant]} ${className}`}
    >
      {children}
    </motion.button>
  );
};

export default Button;





// import React from 'react'

// const baseClasses =
//   'inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60'

// const variants = {
//   solid: 'bg-blue-600 text-white hover:bg-blue-700 shadow-sm',
//   ghost: 'bg-transparent text-slate-700 hover:bg-slate-100',
//   outline:
//     'border border-slate-300 bg-white text-slate-800 hover:bg-slate-50 shadow-sm',
// }

// const sizes = {
//   sm: 'px-3 py-1.5 text-xs',
//   md: 'px-4 py-2 text-sm',
//   lg: 'px-5 py-2.5 text-base',
// }

// export const Button = ({
//   children,
//   type = 'button',
//   variant = 'solid',
//   size = 'md',
//   className = '',
//   ...rest
// }) => {
//   const classes = `${baseClasses} ${variants[variant]} ${sizes[size]} ${className}`
//   return (
//     <button type={type} className={classes} {...rest}>
//       {children}
//     </button>
//   )
// }

