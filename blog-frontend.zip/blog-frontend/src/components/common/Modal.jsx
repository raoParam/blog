// import React from 'react'
// export const Modal = ({ open, title, children, onClose, actions }) => {
//   if (!open) return null

//   return (
//     <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 px-4">
//       <div className="w-full max-w-sm rounded-lg bg-white p-4 shadow-lg">
//         {title && (
//           <h2 className="mb-2 text-sm font-semibold text-slate-900">
//             {title}
//           </h2>
//         )}
//         <div className="text-xs text-slate-600">{children}</div>
//         <div className="mt-4 flex justify-end gap-2">
//           <button
//             type="button"
//             onClick={onClose}
//             className="rounded-md px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-100"
//           >
//             Cancel
//           </button>
//           {actions}
//         </div>
//       </div>
//     </div>
//   )
// }

