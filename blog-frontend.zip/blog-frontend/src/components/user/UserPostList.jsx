// import React from 'react'
// import { BlogList } from '../blog/BlogList'

// export const UserPostList = ({ posts }) => {
//   return <BlogList blogs={posts} pageSize={50} />
// }

