// import React, { useState } from 'react'

// export const ProfileTabs = () => {
//   const [active] = useState('posts')

//   return (
//     <div className="mb-4 flex gap-2 border-b border-slate-200 text-xs">
//       <button
//         type="button"
//         className={`rounded-t-md px-3 py-2 font-medium ${
//           active === 'posts'
//             ? 'bg-white text-slate-900 shadow-sm'
//             : 'text-slate-500'
//         }`}
//       >
//         Posts
//       </button>
//     </div>
//   )
// }

