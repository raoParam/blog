// import React from 'react'
// export const ProfileHeader = ({ user }) => {
//   if (!user) return null

//   return (
//     <div className="mb-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
//       <div className="flex items-center gap-3">
//         <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-600 text-sm font-semibold text-white">
//           {user.username?.[0]?.toUpperCase() || '?'}
//         </div>
//         <div>
//           <p className="text-sm font-semibold text-slate-900">
//             {user.username}
//           </p>
//           <p className="text-xs text-slate-500">{user.email}</p>
//         </div>
//       </div>
//     </div>
//   )
// }

