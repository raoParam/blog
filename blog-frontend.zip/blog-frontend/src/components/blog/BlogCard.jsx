// import React, { memo, useCallback, useMemo, useState } from 'react'
// import { useNavigate } from 'react-router-dom'
// import { formatDate } from '../../utils/formatDate'
// import { truncateText } from '../../utils/truncateText'
// import { Button } from '../common/Button'
// import { likeBlog } from '../../services/blogService'
// import { useAuth } from '../../hooks/useAuth'
import React from 'react'
import { motion } from "framer-motion";
import truncateText from "../../utils/truncateText";
import { useNavigate } from "react-router-dom";

const BlogCard = ({ blog }) => {
  const navigate = useNavigate();

  return (
    <motion.div
      whileHover={{ y: -5 }}
      transition={{ type: "spring", stiffness: 200 }}
      onClick={() => navigate(`/blog/${blog._id}`)}
      className="bg-[#141414] p-8 rounded-xl cursor-pointer border border-neutral-800 hover:border-neutral-700 transition-all duration-300"
    >
      <h2 className="text-2xl font-semibold text-white mb-4 leading-snug">
        {blog.title}
      </h2>

      <p className="text-neutral-400 text-base mb-6 leading-relaxed">
        {truncateText(blog.content, 160)}
      </p>

      <div className="flex justify-between text-sm text-neutral-500">
        <span>
          {blog.isAnonymous ? "Anonymous" : blog.author?.username}
        </span>
        <span>{blog.likes.length} likes</span>
      </div>
    </motion.div>
  );
};

export default BlogCard;



// export const BlogCard = memo(function BlogCard({ blog, onLikeOptimistic }) {
//   const navigate = useNavigate()
//   const { user } = useAuth()
//   const [likeLoading, setLikeLoading] = useState(false)

//   const isLiked = useMemo(
//     () => Boolean(user && blog?.likes?.includes(user._id)),
//     [blog?.likes, user],
//   )

//   const likesCount = blog?.likes?.length || 0

//   const handleOpen = () => {
//     navigate(`/blogs/${blog._id}`)
//   }

//   const handleLike = useCallback(
//     async (e) => {
//       e.stopPropagation()
//       if (!user || likeLoading) return
//       setLikeLoading(true)
//       try {
//         if (onLikeOptimistic) {
//           onLikeOptimistic(blog._id)
//         }
//         await likeBlog(blog._id)
//       } catch {
//         // best-effort; errors handled by parent fetch
//       } finally {
//         setLikeLoading(false)
//       }
//     },
//     [blog._id, likeLoading, onLikeOptimistic, user],
//   )

//   const authorLabel = blog.isAnonymous
//     ? 'Anonymous'
//     : blog.author?.username || 'Unknown'

//   return (
//     <article
//       onClick={handleOpen}
//       className="group flex cursor-pointer flex-col rounded-xl border border-slate-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
//     >
//       <header className="mb-2 flex items-start justify-between gap-2">
//         <h2 className="text-base font-semibold text-slate-900 group-hover:text-blue-700">
//           {blog.title}
//         </h2>
//       </header>
//       <p className="mb-3 text-xs text-slate-600">
//         {truncateText(blog.content, 180)}
//       </p>
//       <footer className="mt-auto flex items-center justify-between gap-3 text-[11px] text-slate-500">
//         <div className="flex flex-col">
//           <span>{authorLabel}</span>
//           <span>{formatDate(blog.createdAt)}</span>
//         </div>
//         <div className="flex items-center gap-2">
//           <Button
//             size="sm"
//             variant={isLiked ? 'solid' : 'outline'}
//             className="px-2 py-1 text-[11px]"
//             onClick={handleLike}
//             disabled={likeLoading}
//           >
//             {isLiked ? 'Liked' : 'Like'} • {likesCount}
//           </Button>
//         </div>
//       </footer>
//     </article>
//   )
// })

