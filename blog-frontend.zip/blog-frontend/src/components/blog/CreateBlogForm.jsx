// import React, { useState } from 'react'
// import { Input } from '../common/Input'
// import { Button } from '../common/Button'

// export const CreateBlogForm = ({ initialValues, onSubmit, loading }) => {
//   const [title, setTitle] = useState(initialValues?.title || '')
//   const [content, setContent] = useState(initialValues?.content || '')
//   const [isAnonymous, setIsAnonymous] = useState(
//     Boolean(initialValues?.isAnonymous),
//   )
//   const [errors, setErrors] = useState({})

//   const handleSubmit = (e) => {
//     e.preventDefault()
//     if (loading) return

//     const trimmedTitle = title.trim()
//     const trimmedContent = content.trim()

//     const newErrors = {}
//     if (!trimmedTitle) newErrors.title = 'Title is required.'
//     if (!trimmedContent) newErrors.content = 'Content is required.'

//     setErrors(newErrors)
//     if (Object.keys(newErrors).length > 0) return

//     onSubmit({
//       title: trimmedTitle,
//       content: trimmedContent,
//       isAnonymous,
//     })
//   }

//   return (
//     <form
//       onSubmit={handleSubmit}
//       className="space-y-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm"
//     >
//       <Input
//         label="Title"
//         name="title"
//         value={title}
//         onChange={(e) => setTitle(e.target.value)}
//         placeholder="Write an engaging headline..."
//         required
//         error={errors.title}
//       />

//       <div className="space-y-1">
//         <label
//           htmlFor="content"
//           className="block text-sm font-medium text-slate-700"
//         >
//           Content<span className="text-red-500"> *</span>
//         </label>
//         <textarea
//           id="content"
//           name="content"
//           rows={8}
//           value={content}
//           onChange={(e) => setContent(e.target.value)}
//           className={`w-full rounded-md border px-3 py-2 text-sm shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 ${
//             errors.content ? 'border-red-500' : 'border-slate-300'
//           }`}
//           placeholder="Share your thoughts..."
//         />
//         {errors.content && (
//           <p className="text-xs text-red-500">{errors.content}</p>
//         )}
//       </div>

//       <label className="flex items-center gap-2 text-xs text-slate-700">
//         <input
//           type="checkbox"
//           checked={isAnonymous}
//           onChange={(e) => setIsAnonymous(e.target.checked)}
//           className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-500"
//         />
//         Post as anonymous
//       </label>

//       <div className="flex justify-end gap-2 pt-2">
//         <Button type="submit" disabled={loading}>
//           {loading ? 'Saving...' : 'Save post'}
//         </Button>
//       </div>
//     </form>
//   )
// }

