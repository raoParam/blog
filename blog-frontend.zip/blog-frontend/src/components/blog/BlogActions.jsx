// import { useState } from 'react'
// import { useNavigate } from 'react-router-dom'
// import { Button } from '../common/Button'
// import { Modal } from '../common/Modal'
// import { deleteBlog } from '../../services/blogService'
// import { useAuth } from '../../hooks/useAuth'

// export const BlogActions = ({ blog, onDeleted }) => {
//   const { user } = useAuth()
//   const navigate = useNavigate()
//   const [open, setOpen] = useState(false)
//   const [deleting, setDeleting] = useState(false)

//   const isOwner = user && blog?.author?._id === user._id
//   if (!isOwner) return null

//   const handleEdit = () => {
//     navigate(`/blogs/${blog._id}/edit`)
//   }

//   const handleDelete = async () => {
//     if (deleting) return
//     setDeleting(true)
//     try {
//       await deleteBlog(blog._id)
//       if (onDeleted) onDeleted()
//       navigate('/home')
//     } catch {
//       // error toast could go here
//     } finally {
//       setDeleting(false)
//       setOpen(false)
//     }
//   }

//   return (
//     <>
//       <div className="flex gap-2">
//         <Button variant="outline" size="sm" onClick={handleEdit}>
//           Edit
//         </Button>
//         <Button
//           variant="ghost"
//           size="sm"
//           className="text-red-600 hover:bg-red-50"
//           onClick={() => setOpen(true)}
//         >
//           Delete
//         </Button>
//       </div>

//       <Modal
//         open={open}
//         title="Delete post?"
//         onClose={() => setOpen(false)}
//         actions={
//           <Button
//             variant="solid"
//             size="sm"
//             className="bg-red-600 hover:bg-red-700"
//             onClick={handleDelete}
//             disabled={deleting}
//           >
//             {deleting ? 'Deleting...' : 'Delete'}
//           </Button>
//         }
//       >
//         <p>Are you sure you want to delete this blog post? This action cannot be undone.</p>
//       </Modal>
//     </>
//   )
// }

