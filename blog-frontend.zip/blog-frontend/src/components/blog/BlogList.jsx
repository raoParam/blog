// import React, { memo, useCallback } from 'react'
// import { BlogCard } from './BlogCard'
// import { EmptyState } from '../common/EmptyState'

// export const BlogList = memo(function BlogList({
//   blogs,
//   onLikeOptimistic,
//   pageSize = 10,
// }) {
//   if (!blogs || blogs.length === 0) {
//     return (
//       <EmptyState
//         title="No blogs yet"
//         message="When posts are created, they will show up here."
//       />
//     )
//   }

//   const sliced = blogs.slice(0, pageSize)

//   const handleLikeOptimistic = useCallback(
//     (id) => {
//       if (onLikeOptimistic) onLikeOptimistic(id)
//     },
//     [onLikeOptimistic],
//   )

//   return (
//     <div className="grid gap-4 md:grid-cols-2">
//       {sliced.map((blog) => (
//         <BlogCard
//           key={blog._id}
//           blog={blog}
//           onLikeOptimistic={handleLikeOptimistic}
//         />
//       ))}
//     </div>
//   )
// })

