// import React from 'react'
// import { CreateBlogForm } from './CreateBlogForm'

// export const EditBlogForm = ({ initialValues, onSubmit, loading }) => {
//   return (
//     <CreateBlogForm
//       initialValues={initialValues}
//       onSubmit={onSubmit}
//       loading={loading}
//     />
//   )
// }

