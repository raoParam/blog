// import React, { useMemo } from 'react'
// import DOMPurify from 'dompurify'

// export const BlogContent = ({ content }) => {
//   const safeHtml = useMemo(() => {
//     const raw = String(content || '')
//     return DOMPurify.sanitize(raw, {
//       USE_PROFILES: { html: true },
//     })
//   }, [content])

//   return (
//     <div
//       className="prose prose-sm max-w-none prose-headings:text-slate-900 prose-p:text-slate-800 prose-a:text-blue-600"
//       dangerouslySetInnerHTML={{ __html: safeHtml }}
//     />
//   )
// }

