// import { useEffect, useState } from 'react'
// import { ERROR_MESSAGES } from '../utils/constants'

// export const useFetch = (asyncFn, deps = []) => {
//   const [data, setData] = useState(null)
//   const [loading, setLoading] = useState(false)
//   const [error, setError] = useState(null)

//   useEffect(() => {
//     let isMounted = true

//     const fetchData = async () => {
//       setLoading(true)
//       setError(null)
//       try {
//         const result = await asyncFn()
//         if (isMounted) {
//           setData(result)
//         }
//       } catch (err) {
//         if (!isMounted) return
//         const message =
//           err?.response?.data?.message ||
//           (err?.message?.toLowerCase().includes('network')
//             ? ERROR_MESSAGES.NETWORK
//             : ERROR_MESSAGES.UNKNOWN)
//         if (isMounted) {
//           setError(message)
//         }
//       } finally {
//         if (isMounted) {
//           setLoading(false)
//         }
//       }
//     }

//     fetchData()

//     return () => {
//       isMounted = false
//     }
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, deps)

//   return { data, loading, error, setData, setError }
// }


