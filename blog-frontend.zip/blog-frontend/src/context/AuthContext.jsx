// import { createContext, useEffect, useMemo, useState } from 'react'
// import { useNavigate } from 'react-router-dom'
// import { loginUser, registerUser } from '../services/authService'
// import { setAuthToken } from '../services/axiosInstance'
// import React from 'react'

// export const AuthContext = createContext(null)

// const STORAGE_KEYS = {
//   TOKEN: 'blog_jwt',
//   USER: 'blog_user',
// }

// export const AuthProvider = ({ children }) => {
//   const [user, setUser] = useState(null)
//   const [token, setToken] = useState(null)
//   const [loading, setLoading] = useState(true)
//   const [authError, setAuthError] = useState(null)
//   const navigate = useNavigate()

//   useEffect(() => {
//     const storedToken = localStorage.getItem(STORAGE_KEYS.TOKEN)
//     const storedUser = localStorage.getItem(STORAGE_KEYS.USER)
//     if (storedToken && storedUser) {
//       try {
//         const parsedUser = JSON.parse(storedUser)
//         setToken(storedToken)
//         setUser(parsedUser)
//         setAuthToken(storedToken)
//       } catch {
//         localStorage.removeItem(STORAGE_KEYS.TOKEN)
//         localStorage.removeItem(STORAGE_KEYS.USER)
//       }
//     }
//     setLoading(false)
//   }, [])

//   useEffect(() => {
//     const handleForcedLogout = () => {
//       handleLogout(false)
//     }

//     window.addEventListener('auth:logout', handleForcedLogout)
//     return () => window.removeEventListener('auth:logout', handleForcedLogout)
//   })

//   const handleLogin = async (credentials) => {
//     if (!credentials.emailId || !credentials.password) {
//       setAuthError('Email and password are required.')
//       return { success: false }
//     }

//     setAuthError(null)

//     try {
//       const payload = {
//         emailId: credentials.emailId.trim(),
//         password: credentials.password.trim(),
//       }

//       const data = await loginUser(payload)
//       if (data?.status !== 'success' || !data?.token || !data?.user) {
//         setAuthError('Unable to log in. Please try again.')
//         return { success: false }
//       }

//       setToken(data.token)
//       setUser(data.user)
//       setAuthToken(data.token)
//       localStorage.setItem(STORAGE_KEYS.TOKEN, data.token)
//       localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(data.user))

//       navigate('/home')
//       return { success: true }
//     } catch (error) {
//       const message =
//         error?.response?.data?.message ||
//         error?.message ||
//         'Failed to log in. Please check your credentials.'
//       setAuthError(message)
//       return { success: false, error: message }
//     }
//   }

//   const handleRegister = async (payload) => {
//     const username = payload.username?.trim()
//     const email = payload.email?.trim()
//     const password = payload.password?.trim()

//     if (!username || !email || !password) {
//       setAuthError('All fields are required.')
//       return { success: false }
//     }

//     if (password.length < 6) {
//       setAuthError('Password must be at least 6 characters.')
//       return { success: false }
//     }

//     setAuthError(null)

//     try {
//       const data = await registerUser({ username, email, password })
//       if (data?.status !== 'success') {
//         setAuthError(data?.message || 'Registration failed. Please try again.')
//         return { success: false }
//       }

//       navigate('/login')
//       return { success: true }
//     } catch (error) {
//       const message =
//         error?.response?.data?.message ||
//         error?.message ||
//         'Failed to register. Please try again.'
//       setAuthError(message)
//       return { success: false, error: message }
//     }
//   }

//   const handleLogout = (redirect = true) => {
//     setToken(null)
//     setUser(null)
//     setAuthToken(null)
//     localStorage.removeItem(STORAGE_KEYS.TOKEN)
//     localStorage.removeItem(STORAGE_KEYS.USER)
//     if (redirect) {
//       navigate('/login')
//     }
//   }

//   const value = useMemo(
//     () => ({
//       user,
//       token,
//       isAuthenticated: Boolean(token && user),
//       loading,
//       authError,
//       login: handleLogin,
//       register: handleRegister,
//       logout: handleLogout,
//     }),
//     [user, token, loading, authError],
//   )

//   return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
// }

