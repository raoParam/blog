export const API_BASE_URL = 'http://localhost:5000/api'

export const ERROR_MESSAGES = {
  NETWORK: 'Network error. Please check your connection and try again.',
  UNKNOWN: 'Something went wrong. Please try again.',
}

