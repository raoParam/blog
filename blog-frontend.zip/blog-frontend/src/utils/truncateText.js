
const truncateText = (text, maxLength = 120) => {
  if (!text) return "";
  return text.length > maxLength
    ? text.substring(0, maxLength) + "..."
    : text;
};

export default truncateText;











// export const truncateText = (text, maxLength = 160) => {
//   if (!text) return ''
//   const clean = String(text).trim()
//   if (clean.length <= maxLength) return clean
//   return `${clean.slice(0, maxLength)}…`
// }

