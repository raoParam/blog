import { Route, Routes } from 'react-router-dom'
import Landing from '../pages/Landing'
// import { Login } from '../pages/Login'
// import { Register } from '../pages/Register'
// import { Home } from '../pages/Home'
// import { SingleBlog } from '../pages/SingleBlog'
// import { CreateBlog } from '../pages/CreateBlog'
// import { EditBlog } from '../pages/EditBlog'
// import { Profile } from '../pages/Profile'
// import { NotFound } from '../pages/NotFound'
import MainLayout from '../components/layout/MainLayout'
// import { ProtectedRoute } from '../components/layout/ProtectedRoute'
import React from 'react'

export const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
    </Routes>
  )
}

